print("aieeeeeeeee")
