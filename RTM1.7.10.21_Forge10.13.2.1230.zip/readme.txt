﻿*************
* Read me ! *
*************

*コンフィグファイルの解説
entity
 "delete bat":trueでコウモリがスポーンしなくなります。
model
 "use ServerModelPack":trueにすると、マルチプレイ時にサーバーからモデルパックをダウンロードします。(クライアント側のみ有効)
 ただし、ダウンロードされるのはファイル名の先頭に"ModelPack_"がついたZipファイルのみです。
rail
 "GeneratingDistance":レールの生成される最大距離。(マルチプレイ時はサーバー側のみ有効)
sound
 "sound crossing gate":踏切の音のタイプ(0か1)
 "sound train":列車の音量(0~100)

*このModで使用している素材

・音声素材
rtm_dc40r_a.ogg
rtm_dc40r_a-i.ogg
rtm_dc40r_go-a.ogg
rtm_dc40r_i.ogg
rtm_dc40r_i-stop.ogg
rtm_dc40r_stn.ogg
rtm_E231sbb_go-mid.ogg
rtm_E231sbb_mid.ogg
rtm_E231sbb_mid-stop.ogg
rtm_E231sbb_mid-top.ogg
rtm_E231sbb_top.ogg
rtm_E231sbb_top-mid.ogg
rtm_wh_00l.ogg

以上は「Simulation Country GAPAN 月本国」様（http://freett.com/gepponkoku/index.htm）よりお借りしました。

joint.ogg
lever.ogg
は「Simulation Country GAPAN 月本国」様のE231com_middle_j.oggを加工させていただきました。

humikiri.ogg : I'sZako 様
よりご提供していただきました。


・テクスチャ
sign_1.png ~ sign_10.png, itemEC.png, itemFC.png, itemTC.png : おなべ 様
sign_11.png ~ sign_17.png : マイクラでGO 様
sign_19.png ~ sign_34.png : いずみ 様
よりご提供していただきました。


・言語ファイル
es_ES.lang ： KWES!-Link 様
zh_CN.lang : Shin504 様 (https://twitter.com/_Shin504_)
よりご提供していただきました。